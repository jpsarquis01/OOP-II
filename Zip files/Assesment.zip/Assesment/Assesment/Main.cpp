#include "Character.h"
#include "MainMenu.H"
#include "Fight.h"

int main()
{
	MainMenu mainmenu;
	mainmenu.MainMenuLoop();

	return 0;
}