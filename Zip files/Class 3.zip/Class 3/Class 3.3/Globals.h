#pragma once

const int gIncrementValue = 10;

int GetSum(int value)
{
	return value + gIncrementValue;
}

int GetDifference(int value)
{
	return value - gIncrementValue;
}