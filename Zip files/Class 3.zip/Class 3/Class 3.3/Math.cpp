#include "Math.h"

int Math::Add(int a, int b)
{
	return a + b;
}

int Math::Sub(int a, int b)
{
	return a - b;
}

int Math::Mul(int a, int b)
{
	return a * b;
}

int Math::Div(int a, int b)
{
	return a/b;
}
