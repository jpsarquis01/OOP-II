#pragma once

// This file contains global variables and function declarations
const int gIncrementValue = 10;

int GetSum(int value)
{
	return value + gIncrementValue;
}

int GetDifference(int value)
{
	return value - gIncrementValue;
}